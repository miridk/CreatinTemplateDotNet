﻿namespace $safeprojectname$.Models
{
    public class TestEf
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
