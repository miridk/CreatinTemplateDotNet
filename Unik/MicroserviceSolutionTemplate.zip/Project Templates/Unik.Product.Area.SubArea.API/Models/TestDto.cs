﻿using Newtonsoft.Json;

namespace $safeprojectname$.Models
{
    public class TestDto
    {  
        public string Name { get; set; }
    }
}
